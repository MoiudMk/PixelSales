package ly.pixel.sales

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.*
import kotlinx.coroutines.launch

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val cost: Double,
    val price: Double,
    val quantity: Int
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val address: String = ""
)

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY id DESC")
    suspend fun all(): List<Product>
    @Insert suspend fun insert(p: Product)
    @Delete suspend fun delete(p: Product)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY id DESC")
    suspend fun all(): List<Customer>
    @Insert suspend fun insert(c: Customer)
}

@Database(entities = [Product::class, Customer::class], version = 1)
abstract class AppDb : RoomDatabase() {
    abstract fun products(): ProductDao
    abstract fun customers(): CustomerDao
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, AppDb::class.java, "pixel_sales.db").build()
        setContent { PixelSalesApp(db) }
    }
}

@Composable
fun PixelSalesApp(db: AppDb) {
    var tab by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf(emptyList<Product>()) }
    var customers by remember { mutableStateOf(emptyList<Customer>()) }

    fun refresh() {
        scope.launch {
            products = db.products().all()
            customers = db.customers().all()
        }
    }
    LaunchedEffect(Unit) { refresh() }

    MaterialTheme {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("بكسل", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            Text("لأنظمة الحماية والشبكات", fontSize = 12.sp)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = {}, label = { Text("الرئيسية") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = {}, label = { Text("المخزون") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = {}, label = { Text("العملاء") })
                    NavigationBarItem(tab == 3, { tab = 3 }, icon = {}, label = { Text("الفاتورة") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Dashboard(padding, products.size, customers.size)
                1 -> ProductScreen(padding, products) {
                    scope.launch { db.products().insert(it); products = db.products().all() }
                }
                2 -> CustomerScreen(padding, customers) {
                    scope.launch { db.customers().insert(it); customers = db.customers().all() }
                }
                else -> InvoicePreview(padding)
            }
        }
    }
}

@Composable
fun Dashboard(padding: PaddingValues, productCount: Int, customerCount: Int) {
    Column(
        Modifier.padding(padding).padding(16.dp).fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("لوحة التحكم", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("📞 0915763524")
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("المنتجات", fontWeight = FontWeight.Bold)
            Text("$productCount صنف مسجل")
        }}
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("العملاء", fontWeight = FontWeight.Bold)
            Text("$customerCount عميل مسجل")
        }}
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("المنظومة تعمل أوفلاين", fontWeight = FontWeight.Bold)
            Text("البيانات محفوظة محلياً على الهاتف.")
        }}
    }
}

@Composable
fun ProductScreen(padding: PaddingValues, products: List<Product>, add: (Product) -> Unit) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.padding(padding).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("المخزون", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Button({ show = true }) { Text("إضافة") }
        }
        LazyColumn {
            items(products) { p ->
                ListItem(
                    headlineContent = { Text(p.name) },
                    supportingContent = { Text("بيع: ${p.price} د.ل  |  الكمية: ${p.quantity}") }
                )
            }
        }
    }
    if (show) {
        ProductDialog({ show = false; show = false }) { add(it); show = false }
    }
}

@Composable
fun ProductDialog(close: () -> Unit, add: (Product) -> Unit) {
    var name by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("إضافة منتج") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج") })
                OutlinedTextField(cost, { cost = it }, label = { Text("سعر التكلفة") })
                OutlinedTextField(price, { price = it }, label = { Text("سعر البيع") })
                OutlinedTextField(qty, { qty = it }, label = { Text("الكمية") })
            }
        },
        confirmButton = {
            Button(onClick = {
                add(Product(name = name, cost = cost.toDoubleOrNull() ?: 0.0,
                    price = price.toDoubleOrNull() ?: 0.0, quantity = qty.toIntOrNull() ?: 0))
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(close) { Text("إلغاء") } }
    )
}

@Composable
fun CustomerScreen(padding: PaddingValues, customers: List<Customer>, add: (Customer) -> Unit) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.padding(padding).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("العملاء", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Button({ show = true }) { Text("إضافة") }
        }
        LazyColumn { items(customers) { c ->
            ListItem(headlineContent = { Text(c.name) }, supportingContent = { Text(c.phone) })
        }}
    }
    if (show) {
        CustomerDialog({ show = false }) { add(it); show = false }
    }
}

@Composable
fun CustomerDialog(close: () -> Unit, add: (Customer) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("إضافة عميل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم العميل") })
                OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") })
                OutlinedTextField(address, { address = it }, label = { Text("العنوان") })
            }
        },
        confirmButton = {
            Button(onClick = { add(Customer(name = name, phone = phone, address = address)) }) { Text("حفظ") }
        },
        dismissButton = { TextButton(close) { Text("إلغاء") } }
    )
}

@Composable
fun InvoicePreview(padding: PaddingValues) {
    Card(Modifier.padding(padding).padding(16.dp).fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("بكسل", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("لأنظمة الحماية والشبكات")
            Text("📞 0915763524")
            HorizontalDivider()
            Text("فاتورة مبيعات", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("رقم الفاتورة: 000001")
            Text("العميل: —")
            Text("الصنف: —")
            Text("الكمية: —")
            HorizontalDivider()
            Text("الإجمالي: 0.00 د.ل", fontWeight = FontWeight.Bold)
            Text("المدفوع: 0.00 د.ل")
            Text("المتبقي: 0.00 د.ل")
            Spacer(Modifier.height(12.dp))
            Text("شكراً لتعاملكم مع بكسل")
        }
    }
}
